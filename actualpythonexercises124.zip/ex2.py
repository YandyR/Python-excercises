#Test comment
print("I could have code like this.") #and the comment after it is ignored

#comments can be used to comment out code so tht the line of code won't run
#printf("Like this")

print("But THIS will run.")
